package org.cap.service;

import org.cap.dao.ILoginDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginService implements ILoginService {
	@Autowired
	private ILoginDao loginDao;
	@Override
	public boolean validateLogin(int CustomerId, String custPwd) {
		// TODO Auto-generated method stub
		return loginDao.validateLogin(CustomerId, custPwd);
	}
	@Override
	public String getcustomerName(int CustmerId) {
		// TODO Auto-generated method stub
		return loginDao.getcustomerName(CustmerId);
	}

}
