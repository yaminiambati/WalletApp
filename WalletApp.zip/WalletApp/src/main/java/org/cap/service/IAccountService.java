package org.cap.service;

import org.cap.model.Account;

public interface IAccountService {
	public void createAccount(Account account);
}
