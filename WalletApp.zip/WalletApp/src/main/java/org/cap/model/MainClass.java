package org.cap.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=factory.createEntityManager();
		
		EntityTransaction transaction= entityManager.getTransaction();
		
		transaction.begin();
		
		Customer customer=new Customer();
		customer.setCustomerPwd("tom123");
		customer.setFirstName("Tom");
		customer.setLastName("Jerry");
		customer.setLastLoginDate(new Date());
		
		
		Account account=new Account();
		account.setAccountNo(32432432432L);
		account.setAccountType("savings");
		
	
		account.setCustomer(customer);
		
		Account account1=new Account();
		account1.setAccountNo(32435435L);
		account1.setAccountType("current");
		account1.setCustomer(customer);
		
		Account account2=new Account();
		account2.setAccountNo(32435435L);
		account2.setAccountType("RD");
		account2.setYears(2);
		account2.setCustomer(customer);
		entityManager.persist(customer);
		entityManager.persist(account);
		entityManager.persist(account1);
		
		
		transaction.commit();


	}

}
