package org.cap.service;

public interface ILoginService {
	
	public boolean validateLogin(int customerId, String custPwd);

	public String getCustName(Integer custId); 


}
