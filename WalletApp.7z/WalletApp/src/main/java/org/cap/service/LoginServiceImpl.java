package org.cap.service;

import org.cap.dao.ILoginDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("loginService")
public class LoginServiceImpl  implements ILoginService{

	@Autowired
	private ILoginDao loginDao;
	
	
	@Override
	public boolean validateLogin(int customerId, String custPwd) {
		return loginDao.validateLogin(customerId, custPwd);
	}


	@Override
	public String getCustName(Integer custId) {
		return loginDao.getCustName(custId);
	}

}
