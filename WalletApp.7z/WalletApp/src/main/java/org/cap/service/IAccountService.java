package org.cap.service;

public interface IAccountService {

}
