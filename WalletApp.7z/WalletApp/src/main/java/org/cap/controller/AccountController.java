package org.cap.controller;


import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.IAccountService;
import org.cap.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {
	
	
	@Autowired
	private ILoginService loginService;
	
	@Autowired
	private IAccountService accountService;
	
	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("userName")String userName,
			@RequestParam("userPwd")String userPwd, HttpSession session) {
		
		Integer custId = Integer.parseInt(userName);
		
		if(loginService.validateLogin(custId, userPwd)) {
			
			session.setAttribute("custId", custId);
			String custName = loginService.getCustName(custId);
			map.put("custName", custName);
			return "main";
		} else {
			return "redirect:/";
		}
		
	}
	
	
	@RequestMapping("/createAccount")
	public String showCreateAccountPage(ModelMap map) {
		map.put("account", new Account());
		return "createAccount";
	}
	
	
	@RequestMapping("/saveAccount")
	public String saveAccount(HttpSession session, @ModelAttribute("account")Account account) {
		Integer custId = Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer = new Customer();
		
		
		return "redirect:createAccount";
	}
	
	@RequestMapping("/showBalance")
	public String showBalancePage() {
		return "showBalance";
	}
	

	@RequestMapping("/deposit")
	public String showDepositPage() {
		return "deposit";
	}
	

	@RequestMapping("/withdraw")
	public String showWithdrawPage() {
		return "withdraw";
	}
	
	@RequestMapping("/fundTransfer")
	public String showFundTransferPage() {
		return "fundTransfer";
	}
	
	@RequestMapping("/summary")
	public String showSummaryPage() {
		return "fundTransfer";
	}
	
	@RequestMapping("/logout")
	public String showLogoutPage() {
		return "logout";
	}
	
}
