package org.cap.dao;

public interface ILoginDao {
	
	public boolean validateLogin(int customerId, String custPwd);

	public String getCustName(Integer custId); 

}
